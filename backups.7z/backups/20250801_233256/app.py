from flask import Flask, request, jsonify, render_template, redirect, url_for, Response
from flask_cors import CORS
import uuid
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)

# In-memory store for webhook metadata and received data
webhook_data = {}
webhook_metadata = {}

@app.route('/')
def index():
    return render_template('index.html', metadata=webhook_metadata)

@app.route('/generate_webhook', methods=['POST'])
def generate_webhook():
    webhook_id = str(uuid.uuid4())
    full_url = request.host_url.rstrip('/') + '/webhook/' + webhook_id
    webhook_metadata[webhook_id] = {
        "id": webhook_id,
        "url": full_url,
        "created_at": datetime.utcnow().isoformat() + "Z"
    }
    webhook_data[webhook_id] = []
    return redirect(url_for('index'))

@app.route('/webhook/<webhook_id>', methods=['POST'])
def webhook(webhook_id):
    if webhook_id not in webhook_data:
        return jsonify({"error": "Invalid webhook ID"}), 404
    try:
        data = request.get_json(force=True)
        timestamp = datetime.utcnow().isoformat() + "Z"
        webhook_data[webhook_id].append({
            "timestamp": timestamp,
            "payload": data
        })
        print(f"Received JSON on {webhook_id} at {timestamp}: {data}")
        return jsonify({"status": "received", "timestamp": timestamp}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/data/<webhook_id>', methods=['GET'])
def show_webhook_data(webhook_id):
    if webhook_id not in webhook_data:
        return jsonify({"error": "Invalid webhook ID"}), 404
    data = webhook_data[webhook_id]
    return render_template('webhook_data.html', webhook_id=webhook_id, data=data)

@app.route('/download/<webhook_id>', methods=['GET'])
def download_webhook_data(webhook_id):
    if webhook_id not in webhook_data:
        return jsonify({"error": "Invalid webhook ID"}), 404
    data = webhook_data[webhook_id]
    json_data = json.dumps(data, indent=2)
    return Response(
        json_data,
        mimetype='application/json',
        headers={
            "Content-Disposition": f"attachment;filename=webhook_{webhook_id}.json"
        }
    )

if __name__ == '__main__':
    app.run(debug=True)
